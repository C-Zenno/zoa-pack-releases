#!/usr/bin/env python3
"""
Bundle Verification Script (Self-Contained)

Verifies an extracted bundle without requiring the full repository.
Can be run from inside an extracted release bundle.

Checks:
- Release stamp is present and bound
- Adapter packs exist with required files
- Example artifacts contain _footer key
- NOTICE.md contains canonical footer

Usage:
    python tools/demo/verify_bundle.py
    python tools/demo/verify_bundle.py --bundle-root /path/to/extracted

Observational artifact only. Non-authoritative. No action implied.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Tuple

# Canonical footer used in all artifacts
CANONICAL_FOOTER = "Observational artifact only. Non-authoritative. No action implied."


def fail(msg: str) -> None:
    print(f"\033[91m[FAIL]\033[0m {msg}")
    sys.exit(1)


def warn(msg: str) -> None:
    print(f"\033[93m[WARN]\033[0m {msg}")


def ok(msg: str) -> None:
    print(f"\033[92m[OK]\033[0m {msg}")


def info(msg: str) -> None:
    print(f"\033[96m[INFO]\033[0m {msg}")


def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"Invalid JSON at {path}: {e}")
        raise


def has_footer_in_json(path: Path) -> Tuple[bool, str]:
    obj = read_json(path)
    if "_footer" not in obj:
        return False, "missing _footer key"
    return True, ""


def has_footer_in_jsonl(path: Path) -> Tuple[bool, str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception as e:
        return False, f"cannot read: {e}"
    if not lines:
        return False, "empty jsonl file"
    for i, line in enumerate(lines, start=1):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            return False, f"invalid json at line {i}"
        if "_footer" not in obj:
            return False, f"missing _footer at line {i}"
    return True, ""


def find_bundle_root(start: Path) -> Path:
    """Find bundle root by looking for contracts/RELEASE_STAMP.json."""
    # Try current directory first
    if (start / "contracts" / "RELEASE_STAMP.json").exists():
        return start

    # Try parent directories (in case script is in tools/demo/)
    for parent in [start.parent, start.parent.parent]:
        if (parent / "contracts" / "RELEASE_STAMP.json").exists():
            return parent

    # Fallback: assume script location
    script_dir = Path(__file__).resolve().parent
    for candidate in [script_dir, script_dir.parent, script_dir.parent.parent]:
        if (candidate / "contracts" / "RELEASE_STAMP.json").exists():
            return candidate

    fail("Cannot find bundle root (no contracts/RELEASE_STAMP.json found)")
    raise RuntimeError("unreachable")


def main():
    parser = argparse.ArgumentParser(description="Verify extracted bundle")
    parser.add_argument(
        "--bundle-root",
        type=Path,
        default=None,
        help="Path to extracted bundle root (auto-detected if not specified)"
    )
    args = parser.parse_args()

    # Find bundle root
    if args.bundle_root:
        root = args.bundle_root.resolve()
    else:
        root = find_bundle_root(Path.cwd())

    print("")
    print("=" * 50)
    print("Bundle Verification")
    print("=" * 50)
    print(f"Bundle root: {root}")
    print("")

    # --- Release Stamp ---
    stamp_path = root / "contracts" / "RELEASE_STAMP.json"
    if not stamp_path.exists():
        fail(f"Missing release stamp: {stamp_path}")

    stamp = read_json(stamp_path)
    release_id = stamp.get("release_id", "<missing>")
    is_bound = bool(stamp.get("is_bound", False))

    print(f"Release ID: {release_id}")
    print(f"is_bound:   {is_bound}")

    if not is_bound:
        warn("Stamp is not bound")
    else:
        ok("Release stamp is bound")

    # --- Adapters ---
    adapters_dir = root / "adapters"
    if not adapters_dir.exists():
        fail(f"Missing adapters directory: {adapters_dir}")

    adapter_dirs = [
        d for d in sorted(adapters_dir.iterdir())
        if d.is_dir() and not d.name.startswith("_")
    ]

    if not adapter_dirs:
        fail("No adapters found")

    print("")
    print(f"Adapters: {len(adapter_dirs)}")

    all_passed = True

    for adir in adapter_dirs:
        adapter_id = adir.name
        print("")
        print(f"--- {adapter_id} ---")

        # Required files
        constraints = adir / "adapter_constraints.json"
        observables = adir / "PHASE1_OBSERVABLES.md"
        minipack = adir / "examples" / "minipack_v1"

        if not constraints.exists():
            print(f"  [FAIL] missing adapter_constraints.json")
            all_passed = False
            continue
        if not observables.exists():
            print(f"  [FAIL] missing PHASE1_OBSERVABLES.md")
            all_passed = False
            continue
        if not minipack.exists():
            print(f"  [FAIL] missing examples/minipack_v1/")
            all_passed = False
            continue

        ok(f"{adapter_id}: required files present")

        # NOTICE.md footer
        notice = minipack / "NOTICE.md"
        if not notice.exists():
            print(f"  [FAIL] missing NOTICE.md")
            all_passed = False
        else:
            txt = notice.read_text(encoding="utf-8")
            if CANONICAL_FOOTER not in txt:
                print(f"  [FAIL] NOTICE.md missing canonical footer")
                all_passed = False
            else:
                ok(f"{adapter_id}: NOTICE footer present")

        # _footer in JSON/JSONL
        json_files = list(minipack.rglob("*.json"))
        jsonl_files = list(minipack.rglob("*.jsonl"))

        footer_ok = True
        for p in sorted(json_files):
            ok_f, why = has_footer_in_json(p)
            if not ok_f:
                print(f"  [FAIL] {p.name}: {why}")
                footer_ok = False
                all_passed = False

        for p in sorted(jsonl_files):
            ok_f, why = has_footer_in_jsonl(p)
            if not ok_f:
                print(f"  [FAIL] {p.name}: {why}")
                footer_ok = False
                all_passed = False

        if footer_ok:
            ok(f"{adapter_id}: _footer checks: PASS")

    # --- Summary ---
    print("")
    print("=" * 50)
    if all_passed:
        ok("Bundle verification PASSED")
    else:
        print("\033[91m[FAIL]\033[0m Bundle verification FAILED")
    print("=" * 50)
    print("")
    print(CANONICAL_FOOTER)
    print("")

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
