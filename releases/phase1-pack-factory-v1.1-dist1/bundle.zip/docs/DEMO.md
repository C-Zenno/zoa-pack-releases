# Phase-1 Pack Factory Demo (v0.1.1)

**Observational artifact only. Non-authoritative. No action implied.**

---

This demo validates structure and provenance only; it does not interpret content or provide recommendations.

It prints release provenance and validates example packs.
It does not interpret meaning, recommend actions, or make determinations.

---

## Preconditions

- Python 3.11+

---

## Quick Run (60 seconds)

```bash
# 1) Clone
git clone <repo-url>
cd u3r_lab

# 2) Run demo
python tools/demo/demo_phase1.py
```

---

## From Bundle (Downloaded Release)

If you downloaded the release bundle instead of cloning:

```bash
# 1) Extract
unzip phase1-pack-factory-*.zip
cd phase1-pack-factory-*

# 2) Verify checksum
# Linux/macOS:
shasum -a 256 -c SHA256SUMS

# Windows PowerShell:
Get-Content SHA256SUMS | ForEach-Object {
    $parts = $_ -split '\s+'
    $expected = $parts[0]
    $file = $parts[1]
    $actual = (Get-FileHash $file -Algorithm SHA256).Hash.ToLower()
    if ($actual -eq $expected) { "[OK] $file" } else { "[FAIL] $file" }
}

# 3) Run demo
python tools/demo/demo_phase1.py
```

---

## What the Demo Does

1. **Reads release stamp** — prints release ID, bound state, timestamp
2. **Checks toolchain lock** — confirms python version and hash algorithm
3. **Discovers adapters** — scans `adapters/` for pack directories
4. **Validates each adapter:**
   - Required files exist (`adapter_constraints.json`, `PHASE1_OBSERVABLES.md`)
   - Example minipack exists (`examples/minipack_v1/`)
   - NOTICE.md contains canonical footer
   - All JSON/JSONL artifacts contain `_footer` key
   - Prohibited phrase sweep passes (using adapter's `lintable_patterns`)
5. **Prints structural summary** — interval/marker counts from `stats.json`

---

## Expected Output

```
==================================================
Phase-1 Demo: Pack Factory Verification
==================================================

Release ID:   v0.1.1
is_bound:     True
Generated:    2026-01-13T...
Toolchain:    python=3.14.0, hash_alg=BLAKE2b-256

Adapters discovered: 3

--- Adapter: baseline ---
[OK] baseline: required files present
[OK] baseline: NOTICE footer present
[OK] baseline: _footer checks: PASS
[OK] baseline: lintable_patterns sweep: PASS
[INFO] baseline: minipack contains 3 intervals, 5 markers

--- Adapter: cyber ---
[OK] cyber: required files present
[OK] cyber: NOTICE footer present
[OK] cyber: _footer checks: PASS
[OK] cyber: lintable_patterns sweep: PASS
[INFO] cyber: minipack contains 3 intervals, 5 markers

--- Adapter: flow ---
[OK] flow: required files present
[OK] flow: NOTICE footer present
[OK] flow: _footer checks: PASS
[OK] flow: lintable_patterns sweep: PASS
[INFO] flow: minipack contains 3 intervals, 5 markers

==================================================
[OK] All adapters PASSED demo verification
==================================================

Observational artifact only. Non-authoritative. No action implied.
```

---

## What It Does NOT Do

- Interpret patterns or assign meaning
- Make safety, threat, or compliance determinations
- Recommend actions or suggest improvements
- Infer user state, intent, or identity
- Score, rank, or classify

---

## Troubleshooting

### `[FAIL] Missing release stamp`

Run from repo root. The stamp should be at `contracts/RELEASE_STAMP.json`.

### `[FAIL] adapter_id: missing _footer`

All JSON/JSONL example artifacts must include:
```json
"_footer": "Observational artifact only. Non-authoritative. No action implied."
```

### `[FAIL] prohibited pattern(s) matched`

The adapter's `lintable_patterns` found banned phrases in declared text.
Review `adapter_constraints.json` for modal/prescriptive language.

---

## Next Steps

After the demo passes:

1. Review [PACK_CATALOG.md](PACK_CATALOG.md) for available adapters
2. Read [USING_PACKS.md](USING_PACKS.md) for integration guide
3. Verify full bindings: `python scripts/verify_all_packs.py`

---

*Observational artifact only. Non-authoritative. No action implied.*
