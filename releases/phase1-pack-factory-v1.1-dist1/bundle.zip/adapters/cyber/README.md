# Cyber Structural Observer Pack

**Adapter ID:** `cyber`
**Version:** 0.1.0
**Posture:** Observer-only, non-authoritative

---

## Purpose

Cyber Structural Observer is a structural observer that tracks patterns without semantic inference.

---

## What This Adapter Observes

See `CYBER_PHASE1_OBSERVABLES.md` for the complete observable contract.

---

## What This Adapter Does NOT Do

- Make safety determinations
- Make threat determinations
- Infer user state or traits
- Provide recommendations or actions
- Optimize or personalize
- Score, rank, or alert
- Learn or adapt

See `adapter_constraints.json` for complete prohibitions.

---

## Output Artifacts

| Artifact | Description |
|----------|-------------|
| `intervals.jsonl` | Time-windowed structural intervals |
| `markers.jsonl` | Event markers (structural-only) |
| `stats.json` | Aggregate statistics |
| `provenance.json` | Hashes and timestamps |

All outputs include footer: *"Observational artifact only. Non-authoritative. No action implied."*

---

## Governance

- **Doctrine:** OBSERVER_DOCTRINE.md (bound by hash)
- **License:** OEL-1.0 (Observer Evaluation License)
- **Tier:** T2 (Observer Systems)

---

*Observational only. Non-authoritative. No action implied.*
