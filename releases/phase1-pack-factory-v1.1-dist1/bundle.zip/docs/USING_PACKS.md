# Using Adapter Packs

**Observational artifact only. Non-authoritative. No action implied.**

---

This guide explains how to consume adapter packs in your application.

---

## 1. Choose a Pack

Review the [Pack Catalog](PACK_CATALOG.md) to select the appropriate adapter for your domain:

| Domain | Pack |
|--------|------|
| Personal stability patterns | `baseline` |
| Cyber/network structural patterns | `cyber` |
| Flow/stream temporal patterns | `flow` |

---

## 2. Verify Governance Bindings

Before using a pack, verify its governance bindings match the release stamp:

```bash
# Verify all packs
python scripts/verify_all_packs.py

# Verify release bindings
python scripts/verify_release_bindings.py
```

The verifier checks:
- Doctrine hash matches RELEASE_STAMP
- License hash matches RELEASE_STAMP
- Pack constraints inherit frozen constants
- Example artifacts contain required footers

---

## 3. Understand the Observable Contract

Each pack defines what it observes in `PHASE1_OBSERVABLES.md`. This contract specifies:

- **Categories**: Groups of related observables
- **Fields**: Individual data points within each category
- **Exclusions**: What the pack explicitly does NOT observe

Example (baseline):

```
Category: Pacing
Fields: cadence_index, burstiness_ratio, idle_gap_ms
Exclusions: No emotional state, No intent inference
```

---

## 4. Review Example Artifacts

Each pack includes synthetic examples in `examples/minipack_v1/`:

### intervals.jsonl

Time-windowed structural observations:

```json
{"ts_start":"2026-01-13T15:00:00Z","ts_end":"2026-01-13T15:01:00Z","cadence_index":0.42,"jitter_index":0.18,"_footer":"Observational artifact only..."}
```

### markers.jsonl

Point-in-time event markers:

```json
{"ts":"2026-01-13T15:00:12Z","marker_type":"burst_cluster","_footer":"Observational artifact only..."}
```

### stats.json

Aggregate statistics for the pack window:

```json
{
  "pack_window": {"ts_start":"...","ts_end":"...","interval_count":3,"marker_count":5},
  "aggregate_indexes": {"cadence_index":{"mean":0.44,"min":0.38,"max":0.51}},
  "_footer": "Observational artifact only..."
}
```

### provenance.json

Cryptographic provenance binding artifacts to governance:

```json
{
  "schema_version": "1.0.0",
  "pack_id": "baseline.minipack_v1",
  "refs": {
    "adapter_constraints_ref": {"path":"../../adapter_constraints.json","hash":"..."},
    "doctrine_ref": {"doc":"OBSERVER_DOCTRINE.md","hash":"..."},
    "license_ref": {"doc":"OEL-1.txt","hash":"..."}
  },
  "artifacts": [{"path":"intervals.jsonl","hash":"..."}]
}
```

---

## 5. Bind the Pack to Your Application

### Step A: Load Constraints

Load `adapter_constraints.json` to configure your observer:

```python
import json
from pathlib import Path

pack_root = Path("adapters/baseline")
with open(pack_root / "adapter_constraints.json") as f:
    constraints = json.load(f)

# Access declared observables
categories = constraints["declared_observables"]["categories"]
for cat in categories:
    print(f"{cat['id']}: {cat['includes']}")

# Access nonclaims (what this observer does NOT do)
for nonclaim in constraints["declared_nonclaims"]:
    print(f"  - {nonclaim}")
```

### Step B: Verify Hash Bindings

Verify your runtime constraints match the governance hashes:

```python
import hashlib

def blake2b_256(path: Path) -> str:
    """Compute BLAKE2b-256 hash of file."""
    h = hashlib.blake2b(digest_size=32)
    h.update(path.read_bytes())
    return h.hexdigest()

# Verify doctrine binding
doctrine_hash = constraints["governance"]["doctrine"]["hash"]
actual_hash = blake2b_256(Path("docs/specs/OBSERVER_DOCTRINE.md"))
assert doctrine_hash == actual_hash, "Doctrine hash mismatch"
```

### Step C: Emit Compliant Artifacts

When emitting artifacts, follow the pack format:

```python
import json

# Always include _footer
interval = {
    "ts_start": "2026-01-13T15:00:00Z",
    "ts_end": "2026-01-13T15:01:00Z",
    "cadence_index": 0.42,
    "jitter_index": 0.18,
    "_footer": "Observational artifact only. Non-authoritative. No action implied."
}

# Write as JSONL
with open("intervals.jsonl", "a") as f:
    f.write(json.dumps(interval) + "\n")
```

---

## 6. Generate Provenance

After emitting artifacts, generate provenance:

```bash
python scripts/emit_example_provenance.py --pack-root output/my_pack
```

This creates `provenance.json` with:
- BLAKE2b-256 hashes of all artifacts
- References to governance documents
- Generation timestamp

---

## 7. Verify Your Output

Verify your emitted pack passes governance checks:

```bash
python scripts/verify_example_pack.py --pack-root output/my_pack
```

Checks performed:
- All JSON files contain `_footer` key
- All JSONL records contain `_footer` key
- NOTICE.md exists
- Footer values match canonical text

---

## Integration Patterns

### Read-Only Observer

```python
# Load pack, observe, emit artifacts
# No action, no recommendation, no optimization
```

### Downstream Consumer

```python
# Load pack artifacts
# Display structural patterns
# Let human interpret and decide
```

### Audit Pipeline

```python
# Verify provenance hashes
# Check governance bindings
# Log compliance status
```

---

## Common Errors

### "Doctrine hash mismatch"

Your local OBSERVER_DOCTRINE.md differs from the bound version. Pull the latest release.

### "Missing _footer in artifact"

All JSON/JSONL artifacts must include:
```json
"_footer": "Observational artifact only. Non-authoritative. No action implied."
```

### "Pack verification failed"

Run `python scripts/verify_all_packs.py` to identify specific failures.

---

## Governance Reminders

**DO:**
- Emit structural observations only
- Include `_footer` in all artifacts
- Verify hash bindings before deployment
- Let humans interpret patterns

**DO NOT:**
- Infer user state or intent
- Make recommendations or suggestions
- Classify, rank, or score
- Determine safety, threat, or compliance

---

*Observational artifact only. Non-authoritative. No action implied.*
