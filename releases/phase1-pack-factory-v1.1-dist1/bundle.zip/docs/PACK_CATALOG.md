# Adapter Pack Catalog

**Observational artifact only. Non-authoritative. No action implied.**

---

## Overview

Adapter packs are pre-configured observer configurations that emit structural telemetry for specific domains. Each pack:

- Declares what it observes (and explicitly what it does NOT observe)
- Ships with example artifacts demonstrating output format
- Is cryptographically bound to governance documents via BLAKE2b-256 hashes

**Governance:** All packs inherit frozen constants from the canonical skeleton template. See [FROZEN_CONSTANTS.md](../contracts/templates/adapters/FROZEN_CONSTANTS.md).

---

## Available Packs

| Pack | Domain | Observables | Status |
|------|--------|-------------|--------|
| [baseline](#baseline) | Personal stability | 7 categories | Released |
| [cyber](#cyber) | Cyber structural | 6 categories | Released |
| [flow](#flow) | Flow telemetry | 6 categories | Released |

---

## baseline

**ID:** `baseline`
**Version:** 0.1.0
**License:** OEL-1.0

Personal stability observer for structural pattern recognition.

### What It Observes

| Category | Fields |
|----------|--------|
| Pacing | `cadence_index`, `burstiness_ratio`, `idle_gap_ms` |
| Hesitation | `hesitation_count`, `correction_count`, `backspace_ratio` |
| Session Geometry | `session_duration_s`, `active_ratio`, `segment_count` |
| Envelope Stability | `envelope_width`, `compression_ratio`, `drift_vector` |
| Baseline Deviation | `deviation_index`, `trend_direction`, `anchor_offset` |
| Error/Repair | `error_count`, `repair_latency_ms`, `recovery_completeness` |
| Modality Metadata | `input_modality`, `device_type`, `session_context` |

### What It Does NOT Observe

- Emotional state, mood, or affect
- Intent or motivation
- Content meaning or semantics
- User identity or demographics
- Health conditions or diagnoses

### Resources

- [Constraints](../adapters/baseline/adapter_constraints.json)
- [Observable Contract](../adapters/baseline/PHASE1_OBSERVABLES.md)
- [Example Pack](../adapters/baseline/examples/minipack_v1/)

---

## cyber

**ID:** `cyber`
**Version:** 0.1.0
**License:** OEL-1.0

Cyber structural observer for network/system telemetry patterns.

### What It Observes

| Category | Fields |
|----------|--------|
| Cadence/Burstiness | `cadence_index`, `burstiness_ratio`, `inter_event_gap_ms` |
| Jitter/Variance | `jitter_index`, `variance_ratio`, `stability_coefficient` |
| Spectral Geometry | `spectral_density`, `frequency_bands`, `harmonic_ratio` |
| Staleness | `freshness_index`, `last_update_delta_ms`, `decay_rate` |
| Drift/Deviation | `drift_index`, `baseline_offset`, `trend_vector` |
| Discontinuities | `gap_count`, `discontinuity_index`, `boundary_sharpness` |

### What It Does NOT Observe

- Threat classification or attribution
- Attack signatures or indicators
- Malicious intent or behavior
- Vulnerability assessment
- Risk scoring or prioritization

### Resources

- [Constraints](../adapters/cyber/adapter_constraints.json)
- [Observable Contract](../adapters/cyber/PHASE1_OBSERVABLES.md)
- [Example Pack](../adapters/cyber/examples/minipack_v1/)

---

## flow

**ID:** `flow`
**Version:** 0.1.0
**License:** OEL-1.0

Flow telemetry observer for temporal stream patterns.

### What It Observes

| Category | Fields |
|----------|--------|
| Cadence/Burstiness | `cadence_index`, `burstiness_ratio`, `inter_event_gap_ms` |
| Jitter/Variance | `jitter_index`, `variance_ratio`, `stability_coefficient` |
| Drift/Deviation | `drift_index`, `baseline_offset`, `trend_vector` |
| Staleness/Freshness | `freshness_index`, `last_update_delta_ms`, `decay_rate` |
| Discontinuities | `gap_count`, `discontinuity_index`, `boundary_sharpness` |
| Envelope Width/Compression | `envelope_width`, `compression_ratio`, `expansion_velocity` |

### What It Does NOT Observe

- Content semantics or meaning
- User intent or motivation
- Quality judgments or ratings
- Performance recommendations
- Optimization suggestions

### Resources

- [Constraints](../adapters/flow/adapter_constraints.json)
- [Observable Contract](../adapters/flow/PHASE1_OBSERVABLES.md)
- [Example Pack](../adapters/flow/examples/minipack_v1/)

---

## Pack Structure

Every adapter pack contains:

```
adapters/<pack_id>/
├── adapter_constraints.json    # Governance constraints
├── PHASE1_OBSERVABLES.md       # Observable contract
├── PACK_BINDINGS.json          # Hash-match bindings
├── README.md                   # Pack documentation
└── examples/
    └── minipack_v1/
        ├── intervals.jsonl     # Time-windowed intervals
        ├── markers.jsonl       # Event markers
        ├── stats.json          # Aggregate statistics
        ├── provenance.json     # Cryptographic provenance
        └── NOTICE.md           # Legal notice
```

---

## Governance Bindings

All packs are bound to:

| Document | Purpose |
|----------|---------|
| OBSERVER_DOCTRINE.md | Epistemological constraints |
| OEL-1.txt | Observer Evaluation License |
| adapter_constraints.schema.json | Schema validation |
| FROZEN_CONSTANTS.md | Immutable governance values |

Bindings are verified via BLAKE2b-256 hash matching.

---

## Creating New Packs

Use the pack factory:

```bash
python scripts/new_adapter_pack.py --id <pack_id> --name "Human Readable Name"
```

See [ADDING_ADAPTERS.md](ADDING_ADAPTERS.md) for complete instructions.

---

## Verification

Verify all packs:

```bash
python scripts/verify_all_packs.py
```

Verify a specific example pack:

```bash
python scripts/verify_example_pack.py --pack-root adapters/<id>/examples/minipack_v1
```

---

*Observational artifact only. Non-authoritative. No action implied.*
