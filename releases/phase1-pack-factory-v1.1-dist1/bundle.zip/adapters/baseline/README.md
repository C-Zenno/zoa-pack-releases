# Baseline Adapter Pack

**Adapter ID:** `baseline`
**Version:** 0.1.0
**Posture:** Observer-only, non-authoritative

---

## Purpose

Baseline is a personal stability observer that tracks structural patterns in user interaction sessions. It observes temporal and geometric properties without semantic inference.

---

## What Baseline Observes

| Category | Description |
|----------|-------------|
| Pacing & Cadence | Inter-event timing, burstiness, pause distribution |
| Hesitation Markers | Revision counts, pause spikes, stall intervals |
| Session Geometry | Phase segmentation, rhythm changes, transition density |
| Envelope Stability | Variance bands, pacing volatility, trajectory smoothness |
| Baseline Deviation | Delta metrics, novelty score, structural drift |
| Error/Repair Dynamics | Correction loops, retry cycles, state oscillation |
| Modality Metadata | Modality presence, sampling rate, missingness |

All observations are **structural only** — no content, meaning, or semantic inference.

---

## What Baseline Does NOT Do

- Make safety determinations
- Make mental health assessments
- Infer user state or traits
- Provide recommendations or actions
- Optimize or personalize
- Score, rank, or alert
- Learn or adapt

See `adapter_constraints.json` for complete prohibitions.

---

## Output Artifacts

| Artifact | Description |
|----------|-------------|
| `baseline_windows.jsonl` | Pacing stats and cadence markers per window |
| `envelope_summary.json` | Variance bands and stability measures |
| `session_geometry.json` | Phase segments and transition density |
| `drift_summary.json` | Deviation from personal baseline |
| `halt_intervals.jsonl` | Pause durations and friction counts |
| `provenance.json` | Hashes and timestamps |

All outputs include footer: *"Observational artifact only. Non-authoritative. No action implied."*

---

## Governance

- **Doctrine:** OBSERVER_DOCTRINE.md (bound by hash)
- **License:** OEL-1.0 (Observer Evaluation License)
- **Tier:** T2 (Observer Systems)

---

## Files

```
adapters/baseline/
  README.md                     # This file
  adapter_constraints.json      # Declared constraints instance
  outputs/
    samples/                    # Example output artifacts
```

---

*Observational only. Non-authoritative. No action implied.*
