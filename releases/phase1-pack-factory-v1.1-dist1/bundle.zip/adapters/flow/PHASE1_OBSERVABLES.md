# Flow Telemetry Observer Phase-1 Observables Contract

**Version:** 0.1.0
**Posture:** Structural-only, non-semantic, non-authoritative

---

## Purpose

This document defines the observable artifacts emitted by the Flow Telemetry Observer in Phase-1. All artifacts are structural observations — they contain no semantic inference, no recommendations, and no action directives.

---

## Artifact Inventory

| Artifact | Format | Description |
|----------|--------|-------------|
| `intervals.jsonl` | JSONL | Time-windowed structural intervals with index bands |
| `markers.jsonl` | JSONL | Event markers (structural-only, no semantics) |
| `stats.json` | JSON | Aggregate statistics over pack window |
| `provenance.json` | JSON | Hashes, timestamps, version references |

---

## Artifact Schemas

### intervals.jsonl

One JSON object per line. Each object represents a time window.

**Contains:**
- `interval_id` — unique identifier
- `ts_start` — interval start timestamp (ISO 8601)
- `ts_end` — interval end timestamp (ISO 8601)
- `window_s` — window duration in seconds
- `markers` — array of marker IDs in this interval
- `indexes` — object with structural index values
- `bands` — object with band labels (b0, b1, b2, b3) per index
- `_footer` — required non-authoritative disclaimer

**Does NOT contain:**
- Risk scores or levels
- Recommendations or actions
- Semantic labels
- User state inference
- Good/bad judgments

### markers.jsonl

One JSON object per line. Each object represents a structural event marker.

**Contains:**
- `marker_id` — unique identifier
- `ts` — marker timestamp (ISO 8601)
- `marker_type` — structural type
- `marker_class` — category
- `magnitude` — numeric magnitude (no threshold interpretation)
- `support` — object with span_s and locality
- `_footer` — required non-authoritative disclaimer

**Does NOT contain:**
- Interpretation of what markers "mean"
- Cause or intent inference
- Severity or priority labels
- User state inference

### stats.json

Aggregate statistics over the pack window.

**Contains:**
- `pack_window` — object with ts_start, ts_end, interval_count, marker_count
- `aggregate_indexes` — object with mean/min/max per index type
- `marker_breakdown` — count per marker_type
- `_footer` — required non-authoritative disclaimer

**Does NOT contain:**
- "Normal" vs "abnormal" labels
- Health or wellness indicators
- Recommendations based on statistics
- Trend interpretation

### provenance.json

Audit and integrity metadata.

**Contains:**
- `schema_version` — semver
- `pack_id` — identifier
- `generated_at_utc` — ISO 8601 timestamp
- `hashing` — algorithm and encoding specification
- `refs` — hash references to adapter_constraints, doctrine, license
- `artifacts` — array of {path, hash} for each artifact
- `_footer` — required non-authoritative disclaimer

**Does NOT contain:**
- Raw input data
- User identifiers
- Session content

---

## Required Footer

All artifacts must include the `_footer` key with value:

> Observational artifact only. Non-authoritative. No action implied.

---

## Prohibited Content

The following must NEVER appear in any Flow Telemetry Observer artifact:

| Category | Prohibited Patterns |
|----------|---------------------|
| Modal language | should, must, recommend, suggests |
| Authority claims | diagnosis, treatment, intervention |
| Risk language | risk, threat, warning, alert |
| State inference | stressed, anxious, distracted, focused |
| Action directives | improve, optimize, you should |

---

## Versioning

- Phase-1: artifacts above (v0.1.0)
- Future phases may add artifacts but never add semantic inference

---

*Structural observations only. Non-authoritative. No action implied.*
