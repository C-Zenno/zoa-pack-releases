Observational artifact only. Non-authoritative. No action implied.

This example demonstrates output structure for Baseline Phase-1.
It does not include inputs, recommendations, or semantic/intent/identity inference.
