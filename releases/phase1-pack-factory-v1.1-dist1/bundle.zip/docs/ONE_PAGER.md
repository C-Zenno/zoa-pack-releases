# Phase-1 Pack Factory — One Pager

**Observational artifact only. Non-authoritative. No action implied.**

---

## What This Is

A collection of **adapter packs** that define structural telemetry contracts for observer systems. Each pack specifies:

- What structural patterns can be observed (cadence, jitter, drift, etc.)
- What is explicitly NOT observed (semantics, intent, identity, etc.)
- Example artifacts demonstrating output format
- Cryptographic bindings to governance documents

This is **Phase-1** of the Constraint Program — the observer-only foundation.

---

## What This Is NOT

| Not This | Because |
|----------|---------|
| A decisioning system | Observers do not make decisions |
| A recommendation engine | No actions are suggested or implied |
| A semantic interpreter | Content meaning is not analyzed |
| A risk/threat classifier | No safety or threat determinations |
| A user profiler | No identity, intent, or state inference |

**Core principle:** Observe structure, not meaning. Describe patterns, not prescriptions.

---

## 60-Second Demo

```bash
# Clone or download the bundle
git clone <repo-url>
cd u3r_lab

# Run verification demo
python tools/demo/demo_phase1.py
```

Expected output:
```
Release ID:   v0.1.1
is_bound:     True
Adapters discovered: 3
[OK] All adapters PASSED demo verification
```

---

## Available Packs

| Pack | Domain | Observables |
|------|--------|-------------|
| **baseline** | Personal stability | Pacing, hesitation, envelope, deviation |
| **cyber** | Cyber structural | Cadence, jitter, spectral, staleness |
| **flow** | Flow telemetry | Cadence, jitter, drift, discontinuities |

Each pack includes example artifacts you can inspect immediately.

---

## License

**OEL-1.0** — Observer Evaluation License

Key terms:
- Observational artifacts only
- No decisioning, ranking, or scoring
- No semantic inference
- No user state determination
- Attribution required for derivatives

See `registry/licenses/OEL-1.txt` for full text.

---

## Governance

All packs are cryptographically bound to:

- **Doctrine:** OBSERVER_DOCTRINE.md (epistemological constraints)
- **License:** OEL-1.0 (usage boundaries)
- **Schema:** adapter_constraints.schema.json (structural validation)

Bindings use BLAKE2b-256 hashes. Provenance is verifiable.

---

## Links

- [Pack Catalog](PACK_CATALOG.md) — Full documentation of all packs
- [Using Packs](USING_PACKS.md) — Integration guide with code examples
- [Demo Guide](DEMO.md) — Step-by-step verification walkthrough
- [Adding Adapters](ADDING_ADAPTERS.md) — How to create new packs

---

## Contact

This is a research artifact from the Constraint Program. For questions about governance, licensing, or integration, open an issue in the repository.

---

*Observational artifact only. Non-authoritative. No action implied.*
