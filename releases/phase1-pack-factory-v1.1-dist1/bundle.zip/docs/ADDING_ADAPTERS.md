# How to Add an Adapter Pack

This guide explains how to create a new adapter pack using the pack factory.

---

## Quick Start

```bash
# 1. Generate the adapter pack
python scripts/new_adapter_pack.py --id <adapter_id> --name "Human Readable Name"

# 2. Edit the observables contract
# adapters/<adapter_id>/PHASE1_OBSERVABLES.md

# 3. Add example artifacts
# adapters/<adapter_id>/examples/minipack_v1/

# 4. Generate provenance
python scripts/emit_example_provenance.py --pack-root adapters/<adapter_id>/examples/minipack_v1

# 5. Verify everything
python scripts/verify_all_packs.py
```

---

## What the Generator Creates

| File | Purpose |
|------|---------|
| `adapter_constraints.json` | Pack constraints (inherits frozen governance) |
| `PHASE1_OBSERVABLES.md` | Observable contract template |
| `PACK_BINDINGS.json` | Hash-match bindings |
| `README.md` | Pack documentation |
| `examples/minipack_v1/` | Example artifact scaffold |

---

## Required Edits

### 1. Update `adapter_constraints.json`

Add adapter-specific observables:

```json
"declared_observables": {
  "categories": [
    {
      "id": "your_observable_id",
      "name": "Your Observable Name",
      "structural_only": true,
      "includes": ["field1", "field2", "field3"]
    }
  ]
}
```

### 2. Update `PHASE1_OBSERVABLES.md`

Document your artifact schemas and fields.

### 3. Add Example Artifacts

Create synthetic examples in `examples/minipack_v1/`:

- `intervals.jsonl` — Time-windowed structural intervals
- `markers.jsonl` — Event markers (structural-only)
- `stats.json` — Aggregate statistics
- (provenance.json is generated)

---

## Posture Reminders

### DO NOT include:
- Semantic inference
- Intent inference
- Recommendations or actions
- Risk/threat language
- Modal language (should, must, recommend)
- User state inference
- Diagnosis or treatment

### ALWAYS include:
- `_footer` key in all JSON/JSONL artifacts
- Footer value: `"Observational artifact only. Non-authoritative. No action implied."`
- Structural-only field names

---

## Verification

Run all checks before committing:

```bash
# Release bindings
python scripts/verify_release_bindings.py

# Example pack footer check
python scripts/verify_example_pack.py --pack-root adapters/<id>/examples/minipack_v1

# Cross-pack sweep
python scripts/verify_all_packs.py

# Golden test (validates generator)
python scripts/tests/test_pack_factory.py
```

---

## Frozen Constants

These values are inherited from the skeleton and must not be changed:

- **8 canonical nonclaims** — See `FROZEN_CONSTANTS.md`
- **Anti-permission statement** — `"Declarations only; not permissions or grants."`
- **Required footer** — `"Observational artifact only. Non-authoritative. No action implied."`
- **14 lintable patterns** — CI enforcement
- **Hash algorithm** — BLAKE2b-256

---

## After Adding

1. Update `adapters/INDEX.md` with your new adapter
2. Sync template: `cp adapters/<id>/adapter_constraints.json contracts/templates/adapters/<id>.adapter_constraints.json`
3. Update hash in `PACK_BINDINGS.json`
4. Run `python scripts/verify_all_packs.py`
5. Commit with: `feat(adapters): Add <id> adapter pack`

---

*Observational artifact only. Non-authoritative. No action implied.*
