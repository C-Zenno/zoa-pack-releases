# Baseline Phase-1 Minipack (output-only example)

This folder contains **synthetic, output-only** example artifacts for the Baseline Phase-1 observer pack.

**Observational artifact only. Non-authoritative. No action implied.**

## Contents

| File | Description |
|------|-------------|
| `intervals.jsonl` | Time-windowed structural intervals |
| `markers.jsonl` | Event markers (structural-only) |
| `stats.json` | Aggregate statistics over the pack window |
| `provenance.json` | Hashing + schema references for auditability |

## Notes

- No input is included. This example is provided to demonstrate **artifact structure** only.
- No semantic interpretation, identity inference, or intent inference is present or implied.

---

*Observational artifact only. Non-authoritative. No action implied.*
