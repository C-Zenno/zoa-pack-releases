# Adapter Pack Index

**Observational artifact only. Non-authoritative. No action implied.**

---

This index lists all registered adapter packs in the governance system.

## Registered Adapters

| Adapter | Description | Tier |
|---------|-------------|------|
| [baseline](#baseline) | Personal stability observer | T2 |
| [cyber](#cyber) | Cyber structural observer | T2 |
| [flow](#flow) | Flow telemetry observer | T2 |

---

## baseline

**ID:** `baseline`
**Name:** Baseline Personal Stability Observer
**Version:** 0.1.0

| Resource | Path |
|----------|------|
| Constraints | [adapter_constraints.json](baseline/adapter_constraints.json) |
| Observables | [PHASE1_OBSERVABLES.md](baseline/PHASE1_OBSERVABLES.md) |
| Examples | [examples/minipack_v1/](baseline/examples/minipack_v1/) |
| Pack Bindings | [PACK_BINDINGS.json](baseline/PACK_BINDINGS.json) |

**Observables:** Pacing, hesitation, session geometry, envelope stability, baseline deviation, error/repair dynamics, modality metadata

---

## cyber

**ID:** `cyber`
**Name:** Cyber Structural Observer
**Version:** 0.1.0

| Resource | Path |
|----------|------|
| Constraints | [adapter_constraints.json](cyber/adapter_constraints.json) |
| Observables | [PHASE1_OBSERVABLES.md](cyber/PHASE1_OBSERVABLES.md) |
| Examples | [examples/minipack_v1/](cyber/examples/minipack_v1/) |
| Pack Bindings | [PACK_BINDINGS.json](cyber/PACK_BINDINGS.json) |

**Observables:** Cadence/burstiness, jitter/variance, spectral geometry, staleness, drift/deviation, discontinuities

---

## flow

**ID:** `flow`
**Name:** Flow Telemetry Observer
**Version:** 0.1.0

| Resource | Path |
|----------|------|
| Constraints | [adapter_constraints.json](flow/adapter_constraints.json) |
| Observables | [PHASE1_OBSERVABLES.md](flow/PHASE1_OBSERVABLES.md) |
| Examples | [examples/minipack_v1/](flow/examples/minipack_v1/) |
| Pack Bindings | [PACK_BINDINGS.json](flow/PACK_BINDINGS.json) |

**Observables:** Cadence/burstiness, jitter/variance, drift/deviation, staleness/freshness, discontinuities, envelope width/compression

---

## Adding New Adapters

Use the pack factory to generate new adapter packs:

```bash
python scripts/new_adapter_pack.py --id <id> --name "Human Readable Name"
```

All adapters inherit frozen governance constants from the skeleton template.

---

## Governance

All adapters are bound by:

- **Doctrine:** OBSERVER_DOCTRINE.md
- **License:** OEL-1.0 (Observer Evaluation License)
- **Schema:** adapter_constraints.schema.json

See `contracts/templates/adapters/FROZEN_CONSTANTS.md` for immutable governance constants.

---

*Observational artifact only. Non-authoritative. No action implied.*
