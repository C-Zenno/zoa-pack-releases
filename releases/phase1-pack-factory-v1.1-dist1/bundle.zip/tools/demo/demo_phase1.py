#!/usr/bin/env python3
"""
Phase-1 demo: prints stamp + validates public pack surfaces.

- No semantics, no recommendations, no safety determinations.
- Structural checks only:
  * release stamp presence + bound state
  * adapter pack required files
  * examples/minipack_v1 existence
  * _footer presence in JSON/JSONL example artifacts
  * NOTICE footer line presence
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Iterable, Tuple

REPO_ROOT = Path(__file__).resolve().parents[2]  # tools/demo/demo_phase1.py -> repo root
STAMP_PATH = REPO_ROOT / "contracts" / "RELEASE_STAMP.json"
TOOLCHAIN_LOCK_PATH = REPO_ROOT / "contracts" / "TOOLCHAIN_LOCK.json"
ADAPTERS_DIR = REPO_ROOT / "adapters"

# Canonical footer used in all artifacts
CANONICAL_FOOTER = "Observational artifact only. Non-authoritative. No action implied."


def fail(msg: str) -> None:
    print(f"\033[91m[FAIL]\033[0m {msg}")
    sys.exit(1)


def warn(msg: str) -> None:
    print(f"\033[93m[WARN]\033[0m {msg}")


def ok(msg: str) -> None:
    print(f"\033[92m[OK]\033[0m {msg}")


def info(msg: str) -> None:
    print(f"\033[96m[INFO]\033[0m {msg}")


def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"Invalid JSON at {path}: {e}")
        raise  # unreachable


def iter_adapters(adapters_dir: Path) -> Iterable[Path]:
    if not adapters_dir.is_dir():
        return []
    for p in sorted(adapters_dir.iterdir()):
        if not p.is_dir():
            continue
        # ignore internal/non-pack dirs
        if p.name.startswith("_"):
            continue
        yield p


def find_minipack(adapter_dir: Path) -> Path:
    return adapter_dir / "examples" / "minipack_v1"


def has_footer_in_json(path: Path) -> Tuple[bool, str]:
    obj = read_json(path)
    if "_footer" not in obj:
        return False, "missing _footer key"
    return True, ""


def has_footer_in_jsonl(path: Path) -> Tuple[bool, str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception as e:
        return False, f"cannot read: {e}"
    if not lines:
        return False, "empty jsonl file"
    for i, line in enumerate(lines, start=1):
        line = line.strip()
        if not line:
            continue  # allow blank lines
        try:
            obj = json.loads(line)
        except Exception:
            return False, f"invalid json at line {i}"
        if "_footer" not in obj:
            return False, f"missing _footer at line {i}"
    return True, ""


def check_notice_footer(notice_path: Path, adapter_id: str) -> None:
    if not notice_path.exists():
        fail(f"{adapter_id}: Missing NOTICE.md: {notice_path}")
    txt = notice_path.read_text(encoding="utf-8")
    if CANONICAL_FOOTER not in txt:
        fail(f"{adapter_id}: NOTICE.md missing canonical footer line")
    ok(f"{adapter_id}: NOTICE footer present")


def sweep_prohibited_phrases(adapter_constraints: dict, adapter_id: str) -> None:
    """
    Minimal text hygiene using adapter's lintable_patterns.
    Applies patterns only to human-readable strings (not hashes/ids).
    Location: declared_outputs.lintable_patterns
    """
    patterns = []
    outputs = adapter_constraints.get("declared_outputs", {})
    lp = outputs.get("lintable_patterns", [])
    if isinstance(lp, list):
        for p in lp:
            if isinstance(p, str) and p:
                patterns.append(p)

    if not patterns:
        warn(f"{adapter_id}: no lintable_patterns in declared_outputs (skipping prohibited sweep)")
        return

    # Collect human-readable strings from known areas
    strings = []

    # Keys to skip (meta-fields that declare patterns, not actual content)
    skip_keys = {
        "hash", "hexdigest", "lintable_patterns", "prohibited_output_patterns",
        "format", "footer_required", "footer_value", "structural_only"
    }

    def collect(obj, depth=0):
        if isinstance(obj, str):
            strings.append(obj)
        elif isinstance(obj, list):
            for x in obj:
                collect(x, depth + 1)
        elif isinstance(obj, dict):
            for k, v in obj.items():
                # skip meta-fields and hash fields
                if str(k).lower() in skip_keys:
                    continue
                collect(v, depth + 1)

    # Focus on adapter metadata only (name, description)
    # Skip declared_outputs entirely - it contains patterns and format specs, not prose
    adapter_meta = adapter_constraints.get("adapter", {})
    collect({"name": adapter_meta.get("name", ""), "description": adapter_meta.get("description", "")})
    # Note: declared_nonclaims are excluded - they describe what is NOT done
    # Note: declared_outputs excluded - contains patterns/format specs, not prose

    haystack = "\n".join(strings)

    hits = []
    for pat in patterns:
        try:
            if re.search(pat, haystack, flags=re.IGNORECASE):
                hits.append(pat)
        except re.error:
            warn(f"{adapter_id}: invalid regex in lintable_patterns: {pat}")

    if hits:
        fail(f"{adapter_id}: prohibited pattern(s) matched in declared text: {hits}")
    ok(f"{adapter_id}: lintable_patterns sweep: PASS")


def print_minipack_summary(minipack: Path, adapter_id: str) -> None:
    """Print structural summary of minipack contents (no interpretation)."""
    stats_path = minipack / "stats.json"
    if stats_path.exists():
        stats = read_json(stats_path)
        window = stats.get("pack_window", {})
        interval_count = window.get("interval_count", "?")
        marker_count = window.get("marker_count", "?")
        info(f"{adapter_id}: minipack contains {interval_count} intervals, {marker_count} markers")


def main() -> None:
    print("")
    print("=" * 50)
    print("Phase-1 Demo: Pack Factory Verification")
    print("=" * 50)
    print("")

    # --- Release Stamp ---
    if not STAMP_PATH.exists():
        fail(f"Missing release stamp: {STAMP_PATH}")

    stamp = read_json(STAMP_PATH)
    release_id = stamp.get("release_id", "<missing>")
    is_bound = bool(stamp.get("is_bound", False))
    generated_at = stamp.get("generated_at_utc", "<missing>")

    print(f"Release ID:   {release_id}")
    print(f"is_bound:     {is_bound}")
    print(f"Generated:    {generated_at}")

    if not is_bound:
        warn("Stamp is not bound (is_bound=false). Public demo expects a bound release.")

    # --- Toolchain Lock ---
    if TOOLCHAIN_LOCK_PATH.exists():
        toolchain = read_json(TOOLCHAIN_LOCK_PATH)
        py_version = toolchain.get("python", "?")
        hash_alg = toolchain.get("hash_algorithm", "?")
        print(f"Toolchain:    python={py_version}, hash_alg={hash_alg}")
    else:
        warn("TOOLCHAIN_LOCK.json not present (reduces determinism proof)")

    # --- Adapters ---
    if not ADAPTERS_DIR.exists():
        fail(f"Missing adapters directory: {ADAPTERS_DIR}")

    adapters = list(iter_adapters(ADAPTERS_DIR))
    if not adapters:
        fail("No adapters found under adapters/")

    print("")
    print(f"Adapters discovered: {len(adapters)}")

    for adir in adapters:
        adapter_id = adir.name
        print("")
        print(f"--- Adapter: {adapter_id} ---")

        constraints_path = adir / "adapter_constraints.json"
        obs_contract = adir / "PHASE1_OBSERVABLES.md"
        minipack = find_minipack(adir)

        if not constraints_path.exists():
            fail(f"{adapter_id}: missing adapter_constraints.json")
        if not obs_contract.exists():
            fail(f"{adapter_id}: missing PHASE1_OBSERVABLES.md")
        if not minipack.exists():
            fail(f"{adapter_id}: missing examples/minipack_v1/")

        ok(f"{adapter_id}: required files present")

        # Check NOTICE.md footer
        notice_path = minipack / "NOTICE.md"
        check_notice_footer(notice_path, adapter_id)

        # Check _footer in all json/jsonl under minipack
        json_files = list(minipack.rglob("*.json"))
        jsonl_files = list(minipack.rglob("*.jsonl"))

        if not json_files and not jsonl_files:
            warn(f"{adapter_id}: no json/jsonl files in minipack_v1")
        else:
            for p in sorted(json_files):
                ok_footer, why = has_footer_in_json(p)
                if not ok_footer:
                    fail(f"{adapter_id}: {p.name} {why}")
            for p in sorted(jsonl_files):
                ok_footer, why = has_footer_in_jsonl(p)
                if not ok_footer:
                    fail(f"{adapter_id}: {p.name} {why}")
            ok(f"{adapter_id}: _footer checks: PASS")

        # Lint sweep using adapter's own patterns
        constraints = read_json(constraints_path)
        sweep_prohibited_phrases(constraints, adapter_id)

        # Print structural summary (no interpretation)
        print_minipack_summary(minipack, adapter_id)

    print("")
    print("=" * 50)
    ok("All adapters PASSED demo verification")
    print("=" * 50)
    print("")
    print(CANONICAL_FOOTER)
    print("")


if __name__ == "__main__":
    main()
